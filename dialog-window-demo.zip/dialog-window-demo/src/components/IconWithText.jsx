import React from "react";

function IconWithText({ icon, text }) {
  return (
    <div className="icon-with-text">
      <span className="icon">{icon}</span>
      <span className="title">{text}</span>
    </div>
  );
}

export default IconWithText;
