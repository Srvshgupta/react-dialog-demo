import React from "react";
import IconWithText from "./IconWithText";
import ButtonGroup from "./ButtonGroup";

function Header({ title, icon, buttons, onClose }) {
  return (
    <div className="dialog-header">
      <IconWithText icon={icon} text={title} />
      <ButtonGroup buttons={buttons} onClose={onClose} location="header" />
    </div>
  );
}

export default Header;
