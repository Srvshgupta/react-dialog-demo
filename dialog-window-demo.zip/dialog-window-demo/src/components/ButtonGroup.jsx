import React from "react";
import Button from "./Button";

function ButtonGroup({ buttons = [], onClose, location }) {
if (!buttons || buttons.length === 0) return null;

  function handleClick(label) {
    if (label.toLowerCase() === "close") {
      onClose();
    } else {
      alert(`${label} clicked from ${location}`);
    }
  }
  return (
    <div className="button-group">
      {buttons.map((btn, idx) => (
        <Button key={idx} label={btn} onClick={() => handleClick(btn)} />
      ))}
    </div>
  );
}

export default ButtonGroup;
