import React from "react";

function Content({ message }) {
  return (
    <div className="dialog-content">
      <p>{message}</p>
    </div>
  );
}

export default Content;
