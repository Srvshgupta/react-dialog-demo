import React from "react";
import Header from "./Header";
import Content from "./Content";
import Footer from "./Footer";
import "./Dialog.css";

function Dialog({ config, onClose }) {
  const { header, content, footer } = config;

  

  return (
    <div className="dialog-overlay">
      <div className="dialog-box">
        <Header
          icon={header.icon}
          title={header.title}
          buttons={header.buttons}
          onClose={onClose}
        />
        <Content message={content} />
        {footer && (
          <Footer
            info={footer.info}
            buttons={footer.buttons}
            onClose={onClose}
          />
        )}
      </div>
    </div>
  );
}

export default Dialog;
