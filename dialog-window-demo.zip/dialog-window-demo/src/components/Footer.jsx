import React from "react";
import ButtonGroup from "./ButtonGroup";

function Footer({ buttons = [], info, onClose }) {
  return (
    <div className="dialog-footer">
        {info && <div className="footer-info">{info}</div>}
      {buttons.length > 0 && (
        <ButtonGroup buttons={buttons} onClose={onClose} location="footer" />
      )}
    </div>
  );
}

export default Footer;
