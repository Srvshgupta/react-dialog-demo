import React from "react";

function Button({ label, onClick }) {
  return (
    <>
    {console.log(label)}
     <button className="dialog-button" onClick={onClick}>{label}</button> 
     </>
  )
  
}

export default Button;
