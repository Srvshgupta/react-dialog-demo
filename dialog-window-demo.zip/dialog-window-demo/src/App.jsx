import { useState } from 'react';
import Dialog from './components/Dialog';


function App() {

  const [dialogConfig, setDialogConfig] = useState(null);

  function openDialog(type){
    switch (type) {
      case "variation1":
        setDialogConfig({
          header: {title: 'Header 1', icon:'🔥', buttons: ["close", "help"]},
          content: 'This is a full dialog.',
          footer: {buttons:["Cancel", "Submit"], info:"some info here "}
        });
        break;

      case "variation2":
        setDialogConfig({
          header: { title: 'Minimal', icon: '❄️', buttons: [] },
          content: 'This is a minimal dialog.',
          footer: { buttons: ['OK', 'close'] },
        })
        break;

      case 'variation3':
        setDialogConfig({
          header: { title: 'No Footer', icon: '📦', buttons: ['close'] },
          content: 'Dialog with no footer.',
        });
        break;
      case 'variation4':
        setDialogConfig({
          header: { title: 'Info Only Footer', icon: '💡', buttons: ['close'] },
          content: 'Just info in footer.',
          footer: { info: 'Information only' },
        });
        break;

      default:
        setDialogConfig(null);
    }
  }


  return (
    <div style={{padding: '20px'}}>
       <h1>React Dialog Window Demo</h1>
       <div style={{marginTop: '10px', marginBottom: '20px'}}>
        <button style={{marginRight: '10px'}} onClick={()=> openDialog("variation1")}>Open Dialog 1</button>
        <button style={{marginRight: '10px'}} onClick={()=> openDialog("variation2")}>Open Dialog 2</button>
        <button style={{marginRight: '10px'}} onClick={()=> openDialog("variation3")}>Open Dialog 3</button>
        <button onClick={()=> openDialog("variation4")}>Open Dialog 4</button>
       </div>
       {dialogConfig && (
        <Dialog config={dialogConfig} onClose={()=>setDialogConfig(null)} />
       )}
    </div>
  )
}

export default App
